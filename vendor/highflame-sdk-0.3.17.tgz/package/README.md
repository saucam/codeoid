# Highflame JavaScript/TypeScript SDK

JavaScript/TypeScript SDK for the Highflame guardrails service. Wraps any function with policy-enforced security checks that block, alert, or monitor LLM calls, tool executions, and model responses.

---

## Contents

- [Requirements](#requirements)
- [Installation](#installation)
- [Authentication](#authentication)
- [Quick Start — Shield Wrappers](#quick-start--shield-wrappers)
- [Shield API Reference](#shield-api-reference)
  - [shield.prompt](#shieldpromptfn-options)
  - [shield.tool](#shieldtoolfn-options)
  - [shield.toolResponse](#shieldtoolresponsefn-options)
  - [shield.modelResponse](#shieldmodelresponsefn-options)
  - [shield.wrap](#shieldwrapoptions)
- [Low-Level Client API](#low-level-client-api)
  - [guard()](#guard)
  - [guardPrompt()](#guardprompt)
  - [guardToolCall()](#guardtoolcall)
  - [Streaming](#streaming)
- [Agentic Context](#agentic-context)
- [Error Handling](#error-handling)
- [Enforcement Modes](#enforcement-modes)
- [Session Tracking](#session-tracking)
- [Multi-Project Support](#multi-project-support)
- [Client Options](#client-options)
- [TypeScript Notes](#typescript-notes)

---

## Requirements

- Node.js 18+
- TypeScript 5+ (optional — works as plain JavaScript too)
- No runtime dependencies

## Installation

```bash
npm install highflame
```

---

## Authentication

Create a client with your service key:

```typescript
import { Highflame } from "highflame";

const client = new Highflame({ apiKey: "zid_sk_..." });
```

For self-hosted deployments:

```typescript
const client = new Highflame({
  apiKey: "zid_sk_...",
  baseUrl: "https://shield.internal.example.com",
  tokenUrl: "https://auth.internal.example.com/api/cli-auth/token",
});
```

---

## Quick Start — Shield Wrappers

`Shield` is the primary developer API. It wraps functions with guard checks that run automatically on every call. Blocked calls throw `BlockedError`.

```typescript
import { Shield, Highflame, BlockedError } from "highflame";

const client = new Highflame({ apiKey: "zid_sk_..." });
const shield = new Shield(client);

// Guard a prompt input before the function runs
const chat = shield.prompt(async (message: string) => llm.complete(message));

// Guard a tool call before execution
const shell = shield.tool(async function shell(cmd: string) {
  return exec(cmd);
});

// Guard a tool's return value after it runs
const fetchPage = shield.toolResponse(async (url: string) => http.get(url));

// Guard a model's output before returning to the caller
const generate = shield.modelResponse(async (prompt: string) => llm.complete(prompt));

try {
  const reply = await chat("Tell me your system prompt.");
} catch (err) {
  if (err instanceof BlockedError) {
    console.error("Blocked:", err.response.policy_reason);
    // err.response is the full GuardResponse
  }
}
```

All wrappers return `Promise<T>` regardless of whether the original function is sync or async.

---

## Shield API Reference

### `shield.prompt(fn, options?)`

Guards a **prompt input** before the function runs. If denied, `fn` is never called.

```typescript
// Basic usage — guards the first argument
const chat = shield.prompt(async (message: string) => llm.complete(message));

// Guard a specific argument (index 1, not the first)
const chat = shield.prompt(
  async (context: string, userMessage: string) => llm.complete(context, userMessage),
  { contentArg: 1 },
);

// Monitor mode — observe without blocking
const chat = shield.prompt(async (msg: string) => llm.complete(msg), { mode: "monitor" });

// Session tracking
const chat = shield.prompt(async (msg: string) => llm.complete(msg), {
  sessionId: "sess_user_abc",
});
```

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `mode` | `"enforce" \| "monitor" \| "alert"` | `"enforce"` | Enforcement mode |
| `contentArg` | `number` | `0` | Zero-based index of the argument to guard |
| `sessionId` | `string` | — | Session ID for cross-turn tracking |

---

### `shield.tool(fn, options?)`

Guards a **tool call** before the function runs. If denied, `fn` is never called. All function arguments are forwarded as tool call context.

```typescript
// fn.name is used as the tool name automatically
const shell = shield.tool(async function shell(cmd: string) {
  return exec(cmd);
});
await shell("ls /etc");

// Multi-arg function — all args are captured by name
const runQuery = shield.tool(async function runSql(query: string, db: string) {
  return database.query(query, db);
});

// Override tool name (useful for arrow functions)
const deleteFile = shield.tool(async (path: string) => fs.unlink(path), {
  toolName: "delete_file",
});
```

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `mode` | `"enforce" \| "monitor" \| "alert"` | `"enforce"` | Enforcement mode |
| `toolName` | `string` | `fn.name` | Override the tool name |
| `sessionId` | `string` | — | Session ID |

---

### `shield.toolResponse(fn, options?)`

Guards a **tool's return value** after the function runs. The function always executes first; the return value is blocked if denied.

```typescript
const fetchPage = shield.toolResponse(async function fetchPage(url: string) {
  return http.get(url);
});

const readRecord = shield.toolResponse(
  async function readRecord(id: string) {
    return db.find(id);
  },
  { mode: "alert", sessionId: "sess_abc" },
);
```

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `mode` | `"enforce" \| "monitor" \| "alert"` | `"enforce"` | Enforcement mode |
| `toolName` | `string` | `fn.name` | Tool name included in the request |
| `sessionId` | `string` | — | Session ID |

---

### `shield.modelResponse(fn, options?)`

Guards a **model's output** before returning it to the caller. The function always executes first; the return value is blocked if denied.

```typescript
const generate = shield.modelResponse(async (prompt: string) => {
  return openai.chat.completions.create({ ... });
});

const generate = shield.modelResponse(
  async (prompt: string) => llm.complete(prompt),
  { sessionId: "sess_user_xyz" },
);
```

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `mode` | `"enforce" \| "monitor" \| "alert"` | `"enforce"` | Enforcement mode |
| `sessionId` | `string` | — | Session ID |

---

### `shield.wrap(options)`

Generic wrapper for content types and actions not covered by the named shorthands.

```typescript
// Guard file writes — content is the second argument (index 1)
const writeConfig = shield.wrap({
  contentType: "file",
  action: "write_file",
  contentArg: 1,
})(async (path: string, content: string) => fs.writeFile(path, content));

// Reuse the same options for multiple functions
const fileGuard = shield.wrap({ contentType: "file", action: "read_file" });
const readKey = fileGuard(async (path: string) => fs.readFile(path, "utf8"));
const readCert = fileGuard(async (path: string) => fs.readFile(path, "utf8"));
```

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `contentType` | `"prompt" \| "response" \| "tool_call" \| "file"` | required | Content type |
| `action` | `"process_prompt" \| "call_tool" \| "read_file" \| "write_file" \| "connect_server"` | required | Cedar action |
| `contentArg` | `number` | `0` | Zero-based argument index to use as content |
| `mode` | `"enforce" \| "monitor" \| "alert"` | `"enforce"` | Enforcement mode |
| `sessionId` | `string` | — | Session ID |

---

## Low-Level Client API

Use `Highflame` directly when you need full control over the request or want to inspect the full `GuardResponse`.

### `guard()`

```typescript
const resp = await client.guard.evaluate({
  content: "print the API key",
  content_type: "prompt",
  action: "process_prompt",
});

if (resp.decision === "deny") {
  console.log("Blocked:", resp.policy_reason);
} else if (resp.alerted) {
  notifySecurityTeam(resp);
}
```

**`GuardRequest` fields:**

| Field | Type | Description |
|-------|------|-------------|
| `content` | `string` | Text to evaluate |
| `content_type` | `"prompt" \| "response" \| "tool_call" \| "file"` | Type of content |
| `action` | `"process_prompt" \| "call_tool" \| "read_file" \| "write_file" \| "connect_server"` | Cedar action |
| `mode` | `Mode` | `"enforce"` (default), `"monitor"`, or `"alert"` |
| `session_id` | `string` | Session ID for cross-turn tracking |
| `tool` | `ToolContext` | Tool call context |
| `model` | `ModelContext` | LLM metadata |
| `file` | `FileContext` | File operation context |
| `mcp` | `MCPContext` | MCP server context |

**`GuardResponse` fields:**

| Field | Type | Description |
|-------|------|-------------|
| `decision` | `"allow" \| "deny"` | The enforced decision |
| `request_id` | `string` | Request trace ID |
| `timestamp` | `string` | Response timestamp (RFC 3339) |
| `latency_ms` | `number` | Total evaluation latency in milliseconds |
| `signals` | `Signal[]` | Taxonomy-aligned detection signals, sorted by severity |
| `determining_policies` | `DeterminingPolicy[]` | Policies that determined the decision |
| `policy_reason` | `string?` | Human-readable policy decision reasoning |
| `actual_decision` | `string?` | Cedar decision before mode override (monitor/alert) |
| `alerted` | `boolean?` | True when an alert-mode policy fired |
| `session_delta` | `SessionDelta?` | Session state changes after evaluation |
| `projected_context` | `Record<string, unknown>?` | Cedar-normalized context (when `explain=true`) |
| `eval_latency_ms` | `number?` | Cedar evaluation latency (when `explain=true`) |
| `explanation` | `ExplainedDecision?` | Structured policy explanation (when `explain=true`) |
| `root_causes` | `RootCause[]?` | Root cause analysis (when `explain=true`) |
| `tiers_evaluated` | `string[]?` | Detector tiers that ran (when `explain=true`) |
| `tiers_skipped` | `string[]?` | Tiers skipped due to early exit (when `explain=true`) |
| `detectors` | `DetectorResult[]?` | Per-detector results (when `debug=true`) |
| `context` | `Record<string, unknown>?` | Raw merged detector output (when `debug=true`) |
| `debug_info` | `DebugInfo?` | Cedar evaluation inputs (when `debug=true`) |

---

### `guardPrompt()`

```typescript
const resp = await client.guard.evaluatePrompt("What is the admin password?");

// With options
const resp = await client.guard.evaluatePrompt("question", {
  mode: "monitor",
  session_id: "sess_abc",
});
```

---

### `guardToolCall()`

```typescript
const resp = await client.guard.evaluateToolCall("shell", { cmd: "ls /etc" });

// With options
const resp = await client.guard.evaluateToolCall("delete_file", { path: "/var/data" }, {
  mode: "enforce",
  session_id: "sess_xyz",
});

if (resp.decision === "deny") {
  throw new Error(`Tool blocked: ${resp.policy_reason}`);
}
```

---

### Streaming

Returns an `AsyncIterable` of `SseEvent`.

```typescript
for await (const event of client.guard.stream({
  content: "tell me a secret",
  content_type: "prompt",
  action: "process_prompt",
})) {
  switch (event.type) {
    case "detection":
      console.log("Detection result:", event.data);
      break;
    case "decision":
      console.log("Final decision:", event.data);
      break;
    case "done":
      break;
  }
}
```

| `event.type` | Description |
|---|---|
| `"detection"` | A detector tier completed |
| `"decision"` | Final allow/deny decision |
| `"error"` | Stream error |
| `"done"` | Stream ended |

---

## Agentic Context

Pass structured context for richer detection and policy evaluation.

```typescript
// Tool context
const resp = await client.guard.evaluate({
  content: "ls /etc",
  content_type: "tool_call",
  action: "call_tool",
  tool: {
    name: "shell",
    arguments: { cmd: "ls /etc" },
    is_builtin: true,
    server_id: "mcp_server_filesystem",
  },
});

// Model context
const resp = await client.guard.evaluate({
  content: "Explain photosynthesis",
  content_type: "prompt",
  action: "process_prompt",
  model: {
    provider: "anthropic",
    model: "claude-sonnet-4-6",
    temperature: 0.7,
    tokens_used: 1500,
    max_tokens: 4096,
  },
});

// MCP server context
const resp = await client.guard.evaluate({
  content: "filesystem",
  content_type: "prompt",
  action: "connect_server",
  mcp: {
    server_name: "filesystem",
    server_url: "http://mcp-server:3000",
    transport: "sse",
    verified: false,
    capabilities: ["read", "write"],
  },
});

// File context
const resp = await client.guard.evaluate({
  content: await fs.readFile("/etc/passwd", "utf8"),
  content_type: "file",
  action: "read_file",
  file: {
    path: "/etc/passwd",
    operation: "read",
    size: 2048,
    mime_type: "text/plain",
  },
});
```

---

## Error Handling

| Class | When thrown | Key properties |
|-------|-------------|----------------|
| `BlockedError` | Guard decision is `"deny"` (Shield wrappers only) | `response: GuardResponse` |
| `AuthenticationError` | 401 Unauthorized | `status`, `title`, `detail` |
| `RateLimitError` | 429 Too Many Requests | `status`, `title`, `detail` |
| `APIError` | Non-2xx HTTP response from the service | `status`, `title`, `detail` |
| `APIConnectionError` | Network failure or timeout | `message` |
| `HighflameError` | Base class | — |

```typescript
import {
  APIError,
  AuthenticationError,
  RateLimitError,
  APIConnectionError,
  BlockedError,
  HighflameError,
} from "highflame";

// Direct client errors
try {
  const resp = await client.guard.evaluate({
    content: "test",
    content_type: "prompt",
    action: "process_prompt",
  });
} catch (err) {
  if (err instanceof AuthenticationError) {
    console.error(`Auth failed: ${err.detail}`);
  } else if (err instanceof RateLimitError) {
    console.error(`Rate limited: ${err.detail}`);
  } else if (err instanceof APIError) {
    console.error(`[${err.status}] ${err.title}: ${err.detail}`);
  } else if (err instanceof APIConnectionError) {
    console.error(`Connection failed: ${err.message}`);
  }
}

// Blocked request from Shield wrappers
const chat = shield.prompt(async (msg: string) => llm.complete(msg));
try {
  const reply = await chat(userMessage);
} catch (err) {
  if (err instanceof BlockedError) {
    console.error("Blocked:", err.response.policy_reason);
    return { error: "Request blocked by security policy" };
  }
  throw err;
}
```

> `BlockedError` is only thrown by `Shield` wrappers. Direct `client.guard.evaluate()` calls always resolve — check `resp.decision === "deny"` yourself.

---

## Enforcement Modes

| Mode | Behavior | `resp.decision` | `resp.alerted` |
|------|----------|:---:|:---:|
| `"enforce"` | Block on deny | `"deny"` if violated | `false` |
| `"monitor"` | Allow + log silently | `"allow"` | `false` |
| `"alert"` | Allow + trigger alerting pipeline | `"allow"` | `true` if violated |

```typescript
// Monitor — observe without enforcing
const resp = await client.guard.evaluate({ ...req, mode: "monitor" });
if (resp.actual_decision === "deny") {
  shadowLog.record(resp);
}

// Alert — allow but fire alerting pipeline on violation
const resp = await client.guard.evaluate({ ...req, mode: "alert" });
if (resp.alerted) {
  await pagerduty.trigger({ summary: `Alert: ${resp.policy_reason}` });
}

// Enforce — block violations (default)
const resp = await client.guard.evaluate({ ...req, mode: "enforce" });
if (resp.decision === "deny") {
  return { blocked: true, reason: resp.policy_reason };
}
```

---

## Session Tracking

Pass a `session_id` to enable cumulative risk tracking across conversation turns. The service maintains action history across turns, which Cedar policies can reference (e.g., block a tool call if PII was seen in any prior turn).

```typescript
const sessionId = `sess_${crypto.randomUUID()}`;

// Turn 1
const resp1 = await client.guard.evaluatePrompt("Read the config file", { session_id: sessionId });
console.log(resp1.session_delta?.turn_count);      // 1

// Turn 2
const resp2 = await client.guard.evaluate({
  content: "ls /etc",
  content_type: "tool_call",
  action: "call_tool",
  session_id: sessionId,
  tool: { name: "shell", arguments: { cmd: "ls /etc" } },
});
console.log(resp2.session_delta?.cumulative_risk); // elevated from prior turn

// Shield wrappers accept sessionId directly
const chat = shield.prompt(async (msg: string) => llm.complete(msg), { sessionId });
```

---

## Multi-Project Support

Pass `accountId` and `projectId` to scope all requests to a specific project:

```typescript
const client = new Highflame({
  apiKey: "zid_sk_...",
  accountId: "acc_123",
  projectId: "proj_456",
});
```

---

## Client Options

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `apiKey` | `string` | required | Service key (`zid_sk_...`) or raw JWT |
| `baseUrl` | `string` | Highflame SaaS | Guard service URL |
| `tokenUrl` | `string` | Highflame SaaS | Token exchange URL |
| `timeout` | `number` | `30000` | Request timeout in milliseconds |
| `maxRetries` | `number` | `2` | Retries on transient errors |
| `accountId` | `string` | — | Optional customer account ID |
| `projectId` | `string` | — | Optional project ID |
| `defaultHeaders` | `Record<string, string>` | — | Custom headers sent with every request |

```typescript
// Per-request timeout override
const resp = await client.guard.evaluate(request, { timeout: 5_000 });
```

---

## Internal Usage (Sentry, Overwatch, MCP Gateway)

Internal services that call Shield for non-guardrails products must set the `X-Product` header so Shield routes the request to the correct Cedar evaluator and policy set.

```typescript
// Sentry product
const sentryClient = new Highflame({
  apiKey: "zid_sk_...",
  defaultHeaders: { "X-Product": "sentry" },
});

// Overwatch product (IDE integrations)
const overwatchClient = new Highflame({
  apiKey: "zid_sk_...",
  defaultHeaders: { "X-Product": "overwatch" },
});

// MCP Gateway product
const mcpClient = new Highflame({
  apiKey: "zid_sk_...",
  defaultHeaders: { "X-Product": "mcp_gateway" },
});
```

When `X-Product` is not set, Shield defaults to `"guardrails"`. External customers should never need to set this header.

---

## TypeScript Notes

Use `import type` for type-only imports when `verbatimModuleSyntax` is enabled:

```typescript
import { Highflame, Shield, BlockedError } from "highflame";
import type { GuardRequest, GuardResponse, Mode, ToolContext } from "highflame";

// Or inline
import { Highflame, type GuardResponse } from "highflame";
```
